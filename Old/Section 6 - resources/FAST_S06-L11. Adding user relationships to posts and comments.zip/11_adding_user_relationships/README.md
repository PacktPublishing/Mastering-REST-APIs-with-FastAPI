---
title: "User relationships in our database"
description: "Learn how to include a user ID in tables to create a relationship between users and other models"
created: "2023-05-31"
slug: adding-user-relationships-to-other-tables
---

# User relationships in our database

There is no text content for this lecture yet. Please watch the video above and see the code changes below!
